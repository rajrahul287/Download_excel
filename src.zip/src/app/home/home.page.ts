import { Component } from '@angular/core';
import { AuthenticationService } from '../services/authentication.service';
import { IBiodatas,Case,CaseData } from '../biodata';
import { saveAs } from 'file-saver';
import * as XLSX from 'xlsx';
import { HttpClientModule, HttpClient } from '@angular/common/http';

const EXCEL_EXTENSION = '.xlsx';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  public data:string;
  id:number;
  public jsondata = [
  ];
  caseArr: Array<Case> = [];
  constructor(private restservice: AuthenticationService,private http: HttpClient ){}

downloadFile(){
  console.log("Inside login(). Logins will be handle here.")
  
    this.restservice.downloadFile().subscribe((data :any)=> {


      let sheet = XLSX.utils.json_to_sheet(data);
      let wb = {
        SheetNames: ["export"],
        Sheets: {
          "export": sheet
        }
      };
    
      let wbout = XLSX.write(wb, {
        bookType: 'xlsx',
        bookSST: false,
        type: 'binary'
      });
    
      function s2ab(s) {
        let buf = new ArrayBuffer(s.length);
        let view = new Uint8Array(buf);
        for (let i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
      }
      let blob = new Blob([s2ab(wbout)], { type: 'application/octet-stream' });
      saveAs(blob, "signs.xlsx");

      console.log("2,Inside download().")
      this.jsondata = data
      console.log(this.jsondata);
      console.log('data download successful');

    }, error => {
      console.log('Error: ', error)
    });

}

}
