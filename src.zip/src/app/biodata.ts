export  interface IBiodatas{
    userId:string,
    password:string,
    id:number,
    title:string,
    body:string,
    username: string,
    firstName: string,
    lastName: string,
    token: string,
    email:string,
    user_id:string,
    data:string,
    
    
}
export class CaseData
{
  signs : Case;
  previousTable : string;
  previousId: string;

}

export class Case{


  
    type:string;
    id:string;
    signsv1Hid:string;
   
    empno:string;
    signsv1Complaint:string;
    signsv1Personal:string;
    signsv1Family:string;
    signsv1Otherpersonal:string;
    signsv1Otherfamily:string;
    name:string;
    othercomplain:String;
  seqNo: number;
  signsv1CreatedBy:string;
  signsv1CreatedOnClient:Date;
  signsv1ValidFlag: boolean;
  bookmarkId: string;
  bookmarkDk: any;
  signsv1Dk: string;
  signsv1UsedFlag: boolean;
  signsbkv1Dk: any;

  
  }