import { Injectable, Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IBiodatas, } from '../biodata';
import { Observable } from 'rxjs/internal/Observable';
import { BehaviorSubject, of } from 'rxjs';
import { Platform, NavController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
import { ToastController } from '@ionic/angular';
import { catchError, tap } from 'rxjs/operators';
import { HomePage } from '../home/home.page';
import { ListPage } from '../list/list.page';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {


 
 constructor(private http:HttpClient) {
   
  }


  downloadFile(): Observable<IBiodatas[]>{
    console.log('this is service method')
    return this.http.get<IBiodatas[]>('http://10.60.201.247:3001/api/RoamsUsers')
  }

 

}
